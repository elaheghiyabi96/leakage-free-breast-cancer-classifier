
#!/usr/bin/env python3
"""
build_splits.py — BreakHis-IB Split Builder (compact)
Creates patient-held-out splits:
  - StrictBalanced test: subtype-balanced per magnification
  - Natural test: preserves original proportions with patient holdout
"""
from __future__ import annotations
import argparse, os, re, shutil, json, random
from pathlib import Path
from typing import Dict, Tuple, List
import numpy as np, pandas as pd

IMG_EXTS = {".png",".jpg",".jpeg",".tif",".tiff",".bmp"}
SUBTYPE_CANON = {
    "adenosis": ("A","benign"),
    "fibroadenoma": ("F","benign"),
    "phyllodes_tumor": ("PT","benign"),
    "tubular_adenoma": ("TA","benign"),
    "ductal_carcinoma": ("DC","malignant"),
    "lobular_carcinoma": ("LC","malignant"),
    "mucinous_carcinoma": ("MC","malignant"),
    "papillary_carcinoma": ("PC","malignant"),
}
SUBTYPE_ALIASES = {
    "adenosis":"adenosis","fibroadenoma":"fibroadenoma",
    "phyllodes":"phyllodes_tumor","phyllodes_tumor":"phyllodes_tumor",
    "tubular_adenoma":"tubular_adenoma",
    "ductal_carcinoma":"ductal_carcinoma","ductal":"ductal_carcinoma",
    "lobular_carcinoma":"lobular_carcinoma","lobular":"lobular_carcinoma",
    "mucinous_carcinoma":"mucinous_carcinoma","mucinous":"mucinous_carcinoma",
    "papillary_carcinoma":"papillary_carcinoma","papillary":"papillary_carcinoma",
}
SUBTYPE_CODE2NAME = {v[0]:k for k,v in SUBTYPE_CANON.items()}
MAG_REGEX = re.compile(r"(?:^|[_\-/\\])(?P<mag>40|100|200|400)X(?:[_\-/\\]|$)", re.I)
FNAME_REGEX = re.compile(r"SOB[_-](?P<bm>[BM])[_-](?P<code>A|F|PT|TA|DC|LC|MC|PC)-(?P<pnum>\d+)-\d+-?(?P<mag>40|100|200|400)X", re.I)

def infer_label_from_path(p:Path):
    s=p.as_posix().lower()
    if "benign" in s: return "benign"
    if "malignant" in s: return "malignant"
def infer_subtype_from_path(p:Path):
    s=p.as_posix().lower()
    for alias,canon in SUBTYPE_ALIASES.items():
        if f"/{alias}/" in s or s.endswith(f"/{alias}") or f"_{alias}_" in s or f"-{alias}-" in s:
            return canon
def infer_magnification(p:Path):
    m=MAG_REGEX.search(p.as_posix())
    if m: return int(m.group("mag"))
    b=p.name.lower()
    for k in (40,100,200,400):
        if f"{k}x" in b: return k
def infer_from_filename(p:Path):
    m=FNAME_REGEX.search(p.name) or FNAME_REGEX.search(p.as_posix())
    if not m: return {}
    label= "benign" if m.group("bm").upper()=="B" else "malignant"
    code=m.group("code").upper()
    mag=int(m.group("mag"))
    pid=f"{code}-{m.group('pnum')}"
    return {"label":label,"subtype":SUBTYPE_CODE2NAME.get(code),"subtype_code":code,"magnification":mag,"patient_id":pid}
def robust_parse_record(p:Path):
    rec={"path":str(p),"label":None,"subtype":None,"subtype_code":None,"magnification":None,"patient_id":None,"parse_issue":None}
    label=infer_label_from_path(p); subtype=infer_subtype_from_path(p); mag=infer_magnification(p); sc=None
    if subtype in SUBTYPE_CANON:
        sc, canon_label = SUBTYPE_CANON[subtype]; label = label or canon_label
    fn=infer_from_filename(p)
    label = label or fn.get("label"); subtype = subtype or fn.get("subtype")
    sc = sc or fn.get("subtype_code"); mag = mag or fn.get("magnification")
    pid = fn.get("patient_id")
    rec.update({"label":label,"subtype":subtype,"subtype_code":sc,"magnification":mag,"patient_id":pid})
    missing=[k for k in ["label","subtype","subtype_code","magnification","patient_id"] if not rec[k]]
    if missing: rec["parse_issue"]="missing:"+",".join(missing)
    return rec

def sample_balanced_by_cell(df, target_k, rng):
    picked=[]; short={}
    avail=df.groupby(["magnification","subtype"]).size().rename("n").reset_index()
    for _,row in avail.sort_values("n").iterrows():
        mag,st=int(row.magnification),row.subtype
        K=int(target_k.get((mag,st),0))
        if K<=0: continue
        cell=df[(df.magnification==mag)&(df.subtype==st)]
        bypid={pid:g for pid,g in cell.groupby("patient_id")}
        if not bypid: short[(mag,st)]=K; continue
        rr=[list(g.index) for g in bypid.values()]
        for lst in rr: rng.shuffle(lst)
        flat=[]
        while any(rr) and len(flat)<K:
            for lst in rr:
                if lst and len(flat)<K: flat.append(lst.pop())
        if len(flat)<K: short[(mag,st)]=K-len(flat)
        if flat: picked.append(df.loc[flat])
    out=pd.concat(picked).drop_duplicates() if picked else pd.DataFrame(columns=df.columns)
    return out, short

def compute_auto_K(df):
    target={}
    for mag,g in df.groupby("magnification"):
        counts=g.groupby("subtype").size()
        mmin=int(counts.min()) if len(counts)>0 else 0
        for st in SUBTYPE_CANON.keys():
            n=int(g[g.subtype==st].shape[0])
            target[(int(mag),st)]=min(mmin,n)
    return target

def assign_split_strict_balanced(df, strict_k, val_k, seed):
    rng=np.random.RandomState(seed); pool=df.copy()
    target=compute_auto_K(pool) if strict_k is None else {(int(m),st):min(int(strict_k),int(pool[(pool.magnification==m)&(pool.subtype==st)].shape[0])) for m in sorted(pool.magnification.unique()) for st in SUBTYPE_CANON.keys()}
    test,short=sample_balanced_by_cell(pool,target,rng)
    if short:
        feas={(m,st):min(target[(m,st)], int(pool[(pool.magnification==m)&(pool.subtype==st)].shape[0])) for (m,st) in target}
        new={}
        for m in sorted(pool.magnification.unique()):
            ks=[feas[(m,st)] for st in SUBTYPE_CANON.keys() if (m,st) in feas]
            if ks:
                K=min(ks)
                for st in SUBTYPE_CANON.keys(): new[(m,st)]=K
        test,_=sample_balanced_by_cell(pool,new,rng); target=new
    test_pids=set(test.patient_id.unique()); remain=pool[~pool.patient_id.isin(test_pids)].copy()
    valtarget={(m,st):min(int(val_k), int(remain[(remain.magnification==m)&(remain.subtype==st)].shape[0])) for (m,st) in target}
    val,_=sample_balanced_by_cell(remain,valtarget,rng)
    val_pids=set(val.patient_id.unique()); train=remain[~remain.patient_id.isin(val_pids)].copy()
    out=df.copy(); out["split"]="train"; out.loc[out.index.isin(val.index),"split"]="val"; out.loc[out.index.isin(test.index),"split"]="test_strict_balanced"
    rep={"n_train":int((out.split=="train").sum()),"n_val":int((out.split=="val").sum()),"n_test_strict_balanced":int((out.split=="test_strict_balanced").sum())}
    return out, rep, target, valtarget

def assign_split_natural(df, frac, absn, seed):
    rng=np.random.RandomState(seed); pats=list(df.patient_id.unique()); rng.shuffle(pats)
    target=absn if absn is not None else int(round(frac*len(df)))
    testp=set(); n=0
    for pid in pats:
        k=df[df.patient_id==pid].shape[0]
        if n+k<=target or n==0: testp.add(pid); n+=k
        if n>=target: break
    remain=df[~df.patient_id.isin(testp)]; test=df[df.patient_id.isin(testp)]
    remp=list(remain.patient_id.unique()); rng.shuffle(remp); nval=max(1,int(0.1*len(remp)))
    valp=set(remp[:nval]); val=remain[remain.patient_id.isin(valp)]; train=remain[~remain.patient_id.isin(valp)]
    out=df.copy(); out["split"]="train"; out.loc[out.index.isin(val.index),"split"]="val"; out.loc[out.index.isin(test.index),"split"]="test_natural"
    rep={"n_train":int((out.split=='train').sum()),"n_val":int((out.split=='val').sum()),"n_test_natural":int((out.split=='test_natural').sum())}
    return out, rep

def check_leak(df, col='split'):
    probs={}
    splits=df[col].unique().tolist()
    pid_by={s:set(df[df[col]==s]['patient_id'].unique()) for s in splits}
    for i in range(len(splits)):
        for j in range(i+1,len(splits)):
            a,b=splits[i],splits[j]
            inter=pid_by[a]&pid_by[b]
            if inter: probs[(a,b)]=sorted(list(inter))
    return probs

def ensure_dir(d:Path): d.mkdir(parents=True, exist_ok=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, default=Path("./breakhis_ib_outputs"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--strict-test-k", type=int, default=None)
    ap.add_argument("--validation-k", type=int, default=10)
    ap.add_argument("--natural-test-fraction", type=float, default=0.2)
    ap.add_argument("--abs-natural-test", type=int, default=None)
    ap.add_argument("--relative-paths", action="store_true")
    ap.add_argument("--materialize", action="store_true")
    ap.add_argument("--materialize-method", choices=["symlink","copy"], default="symlink")
    ap.add_argument("--materialize-dir", type=Path, default=Path("./breakhis_ib_materialized"))
    args=ap.parse_args()
    random.seed(args.seed); np.random.seed(args.seed)
    if not args.root.exists(): raise SystemExit(f"--root not found: {args.root}")
    ensure_dir(args.out_dir)
    # Scan
    files=[p for p in args.root.rglob("*") if p.is_file() and p.suffix.lower() in IMG_EXTS]
    recs=[robust_parse_record(p) for p in files]
    df=pd.DataFrame(recs)
    # Relative paths
    if args.relative_paths:
        def to_rel(x):
            p=Path(x)
            try: return p.relative_to(args.root).as_posix()
            except Exception: return x
        df["path"]=df["path"].map(to_rel)
    # Save meta
    df.to_csv(args.out_dir/"metadata_raw.csv", index=False)
    ok=df[df.parse_issue.isna()].copy(); bad=df[~df.parse_issue.isna()].copy()
    ok.to_csv(args.out_dir/"metadata_ok.csv", index=False)
    bad.to_csv(args.out_dir/"parse_errors.csv", index=False)
    if ok.empty: raise SystemExit("No valid rows parsed.")
    # StrictBalanced
    strict, rep_s, target_k, val_k = assign_split_strict_balanced(ok, args.strict_test_k, args.validation_k, args.seed)
    strict.to_csv(args.out_dir/"splits_strict_balanced.csv", index=False)
    # Natural
    natural, rep_n = assign_split_natural(ok, args.natural_test_fraction, args.abs_natural_test, args.seed)
    natural.to_csv(args.out_dir/"splits_natural.csv", index=False)
    # Leakage
    leak_s=check_leak(strict); leak_n=check_leak(natural)
    # Report
    report={
        "random_seed":args.seed,
        "n_images_total":int(len(ok)),
        "n_patients_total":int(ok['patient_id'].nunique()),
        "strict_balanced":{
            "counts":strict['split'].value_counts().to_dict(),
            "patients_per_split":{s:int(ok[strict['split']==s]['patient_id'].nunique()) for s in strict['split'].unique()},
            "target_k_cells":{f"{m}_{s}":int(K) for (m,s),K in target_k.items()},
            "validation_k_cells":{f"{m}_{s}":int(K) for (m,s),K in val_k.items()},
            "leakage_pairs":{f"{a}|{b}":v for (a,b),v in leak_s.items()},
        },
        "natural":{
            "counts":natural['split'].value_counts().to_dict(),
            "patients_per_split":{s:int(ok[natural['split']==s]['patient_id'].nunique()) for s in natural['split'].unique()},
            "leakage_pairs":{f"{a}|{b}":v for (a,b),v in leak_n.items()},
        },
    }
    with open(args.out_dir/"split_report.json","w") as f: json.dump(report,f,indent=2)
    # Materialize
    if args.materialize:
        def materialize(df_splits, root_out, name):
            base=root_out/name; ensure_dir(base)
            n=0
            for split_name in df_splits['split'].unique():
                sub=base/split_name; ensure_dir(sub)
                for _,r in df_splits[df_splits['split']==split_name].iterrows():
                    src = Path(r['path'])
                    if not src.is_absolute(): src = args.root / src
                    rel = Path(str(r['label']))/str(r['subtype'])/f"{int(r['magnification'])}X"
                    dst_dir = sub/rel; ensure_dir(dst_dir)
                    dst = dst_dir/src.name
                    try:
                        if args.materialize_method=="symlink":
                            if not dst.exists(): os.symlink(src, dst)
                        else:
                            if not dst.exists(): shutil.copy2(src, dst)
                        n+=1
                    except Exception as e:
                        print("Materialize failed:", src, "->", dst, "|", e)
            print(f"Materialized {n} files under {base}")
        ensure_dir(args.materialize_dir)
        materialize(strict, args.materialize_dir, "strict_balanced")
        materialize(natural, args.materialize_dir, "natural")
    print("Done.")
if __name__=="__main__":
    main()
